export interface Item {
    name: string
    description: string
    createdBy: string
    image: string
}
